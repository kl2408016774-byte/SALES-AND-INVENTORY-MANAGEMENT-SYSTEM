<?php
include 'config.php';

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Check if email already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $error = "Email already registered!";
    } else {
        mysqli_query($conn, "INSERT INTO users(name, email, password, profile_image) VALUES('$name', '$email', '$password', 'default.png')");
        $success = "Registration successful! Please login.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap');
        
        body {
            background: linear-gradient(135deg, #fad0c4 0%, #ff9a9e 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .register-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(255, 154, 158, 0.4);
            max-width: 450px;
            width: 100%;
            animation: slideUp 0.5s ease;
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .register-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 42px;
            font-weight: 700;
            color: #ff9a9e;
            margin-bottom: 10px;
        }
        
        .form-control {
            border-radius: 15px;
            border: 2px solid #ffe4e9;
            padding: 12px 18px;
            margin-bottom: 20px;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #ff9a9e;
            box-shadow: 0 0 0 4px rgba(255, 154, 158, 0.2);
        }
        
        .btn-register {
            background: linear-gradient(135deg, #ff9a9e, #fad0c4);
            color: white;
            border: none;
            border-radius: 15px;
            padding: 14px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }
        
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255, 154, 158, 0.4);
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        
        .login-link a {
            color: #ff9a9e;
            text-decoration: none;
            font-weight: 600;
        }
        
        .floating-icon {
            position: absolute;
            font-size: 30px;
            color: rgba(255, 255, 255, 0.3);
            animation: rotate 10s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Decorative floating icons -->
    <div class="floating-icon" style="top: 5%; left: 5%;">💄</div>
    <div class="floating-icon" style="top: 15%; right: 10%; animation-delay: 2s;">💋</div>
    <div class="floating-icon" style="bottom: 10%; left: 15%; animation-delay: 4s;">💅</div>
    
    <div class="register-card">
        <div class="register-header">
            <h1>✨ Join Us ✨</h1>
            <p>Create your account to start managing your makeup shop</p>
        </div>
        
        <?php if(isset($error)) { ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php } ?>
        
        <?php if(isset($success)) { ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php } ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Choose a password" required>
                <small class="text-muted">Password must be at least 6 characters</small>
            </div>
            
            <button type="submit" name="register" class="btn-register">
                <i class="fas fa-user-plus me-2"></i>Create Account
            </button>
            
            <div class="login-link">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </form>
    </div>
</body>
</html>