<?php
session_start();

$conn = mysqli_connect("localhost","root","","inventory_system");

if(!$conn){
    die("Database connection failed");
}
?>