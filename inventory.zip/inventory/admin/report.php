<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get sales data with product details
$data = mysqli_query($conn, "
    SELECT s.*, p.product_name, p.price as product_price
    FROM sales s
    JOIN products p ON s.product_id = p.product_id
    ORDER BY s.sale_date DESC
");

// Calculate totals
$total_sales_amount = 0;
$total_items = 0;
while($row = mysqli_fetch_assoc($data)) {
    $total_sales_amount += $row['total_price'];
    $total_items += $row['quantity'];
}
mysqli_data_seek($data, 0); // Reset pointer
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sales Report - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 style="font-family: 'Playfair Display', serif;">📊 Sales Report</h2>
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print me-2"></i>Print Report
        </button>
    </div>
    
    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-dollar-sign me-2"></i>Total Revenue</h5>
                <div class="stat-number">RM <?php echo number_format($total_sales_amount, 2); ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-cube me-2"></i>Items Sold</h5>
                <div class="stat-number"><?php echo $total_items; ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-chart-line me-2"></i>Average Sale</h5>
                <div class="stat-number">
                    RM <?php 
                    $avg = $total_sales_amount / max(mysqli_num_rows($data), 1);
                    echo number_format($avg, 2); 
                    ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sales Table -->
    <div class="card p-4">
        <h5 class="mb-3" style="font-family: 'Playfair Display', serif;">Transaction Details</h5>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($r = mysqli_fetch_assoc($data)) { ?>
                    <tr>
                        <td><?php echo date('d M Y, h:i A', strtotime($r['sale_date'])); ?></td>
                        <td>
                            <strong><?php echo $r['product_name']; ?></strong>
                        </td>
                        <td><?php echo $r['quantity']; ?></td>
                        <td>RM <?php echo number_format($r['product_price'], 2); ?></td>
                        <td>RM <?php echo number_format($r['total_price'], 2); ?></td>
                        <td><span class="badge badge-success">Completed</span></td>
                    </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <tr class="table-primary">
                        <th colspan="4" class="text-end">Total:</th>
                        <th>RM <?php echo number_format($total_sales_amount, 2); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>