<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get all products for dropdown
$products = mysqli_query($conn, "SELECT * FROM products WHERE quantity > 0 ORDER BY product_name");

if(isset($_POST['record_sale'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    
    // Get product price
    $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE product_id='$product_id'"));
    $total_price = $product['price'] * $quantity;
    
    // Check if enough stock
    if($product['quantity'] >= $quantity) {
        // Record sale
        $query = "INSERT INTO sales (product_id, quantity, total_price, sale_date) 
                  VALUES ('$product_id', '$quantity', '$total_price', NOW())";
        
        if(mysqli_query($conn, $query)) {
            // Update product quantity
            $new_quantity = $product['quantity'] - $quantity;
            mysqli_query($conn, "UPDATE products SET quantity='$new_quantity' WHERE product_id='$product_id'");
            
            $success = "Sale recorded successfully!";
        } else {
            $error = "Error recording sale: " . mysqli_error($conn);
        }
    } else {
        $error = "Not enough stock! Available: " . $product['quantity'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Record Sale - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <h2 class="mb-4" style="font-family: 'Playfair Display', serif;">🛒 Record New Sale</h2>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card p-4">
                <?php if(isset($success)) { ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php } ?>
                
                <?php if(isset($error)) { ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php } ?>
                
                <form method="POST" id="saleForm">
                    <div class="mb-3">
                        <label class="form-label">Select Product</label>
                        <select name="product_id" class="form-select" required onchange="updatePrice()">
                            <option value="">Choose a product...</option>
                            <?php while($product = mysqli_fetch_assoc($products)) { ?>
                            <option value="<?php echo $product['product_id']; ?>" 
                                    data-price="<?php echo $product['price']; ?>"
                                    data-stock="<?php echo $product['quantity']; ?>">
                                <?php echo $product['product_name']; ?> - RM <?php echo $product['price']; ?> 
                                (Stock: <?php echo $product['quantity']; ?>)
                            </option>
                            <?php } ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" min="1" required 
                               onchange="calculateTotal()" id="quantity">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Total Price</label>
                        <div class="input-group">
                            <span class="input-group-text">RM</span>
                            <input type="text" class="form-control" id="total_price" readonly value="0.00">
                        </div>
                    </div>
                    
                    <button type="submit" name="record_sale" class="btn btn-primary w-100">
                        <i class="fas fa-cash-register me-2"></i>Record Sale
                    </button>
                </form>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card p-4">
                <h5 class="mb-3" style="font-family: 'Playfair Display', serif;">💡 Quick Tips</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Make sure to select the correct product</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Check available stock before recording</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Double-check the quantity</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Total price will auto-calculate</li>
                </ul>
                
                <hr>
                
                <h6 class="mb-3">Recent Sales</h6>
                <?php
                $recent = mysqli_query($conn, "
                    SELECT s.*, p.product_name 
                    FROM sales s 
                    JOIN products p ON s.product_id = p.product_id 
                    ORDER BY s.sale_date DESC 
                    LIMIT 5
                ");
                ?>
                <div class="list-group">
                    <?php while($sale = mysqli_fetch_assoc($recent)) { ?>
                    <div class="list-group-item border-0 bg-light mb-2 rounded">
                        <small class="text-muted"><?php echo date('h:i A', strtotime($sale['sale_date'])); ?></small>
                        <div class="d-flex justify-content-between">
                            <span><?php echo $sale['product_name']; ?> (x<?php echo $sale['quantity']; ?>)</span>
                            <strong>RM <?php echo number_format($sale['total_price'], 2); ?></strong>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updatePrice() {
    const select = document.querySelector('select[name="product_id"]');
    const option = select.options[select.selectedIndex];
    if(option.value) {
        const price = option.dataset.price;
        document.getElementById('product_price').value = price;
        calculateTotal();
    }
}

function calculateTotal() {
    const select = document.querySelector('select[name="product_id"]');
    const option = select.options[select.selectedIndex];
    const quantity = document.getElementById('quantity').value;
    
    if(option.value && quantity) {
        const price = option.dataset.price;
        const total = price * quantity;
        document.getElementById('total_price').value = total.toFixed(2);
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>