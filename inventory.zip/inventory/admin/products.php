<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Handle product deletion
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Get image filename before deleting
    $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT product_image FROM products WHERE product_id='$id'"));
    
    // Delete image file if not default
    if($product['product_image'] != 'default.png' && file_exists('../uploads/' . $product['product_image'])) {
        unlink('../uploads/' . $product['product_image']);
    }
    
    mysqli_query($conn, "DELETE FROM products WHERE product_id='$id'");
    header("Location: products.php?msg=deleted");
    exit();
}

// Get all products
$products = mysqli_query($conn, "SELECT * FROM products ORDER BY product_id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 15px 15px 0 0;
        }
        .product-card {
            transition: transform 0.3s;
        }
        .product-card:hover {
            transform: translateY(-5px);
        }
        .default-image {
            width: 100%;
            height: 200px;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 15px 15px 0 0;
        }
        .default-image i {
            font-size: 64px;
            color: white;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 style="font-family: 'Playfair Display', serif;">🛍️ Products Catalog</h2>
        <a href="add_product.php" class="btn btn-primary">
            <i class="fas fa-plus-circle me-2"></i>Add New Product
        </a>
    </div>
    
    <?php if(isset($_GET['msg'])) { ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php 
            if($_GET['msg'] == 'added') echo "Product added successfully!";
            if($_GET['msg'] == 'updated') echo "Product updated successfully!";
            if($_GET['msg'] == 'deleted') echo "Product deleted successfully!";
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php } ?>
    
    <div class="row g-4">
        <?php while($product = mysqli_fetch_assoc($products)) { ?>
        <div class="col-md-4">
            <div class="card h-100 product-card">
                <?php if($product['product_image'] && $product['product_image'] != 'default.png') { ?>
                    <img src="../uploads/<?php echo $product['product_image']; ?>" 
                         class="product-image" alt="<?php echo $product['product_name']; ?>">
                <?php } else { ?>
                    <div class="default-image">
                        <i class="fas fa-magic"></i>
                    </div>
                <?php } ?>
                
                <div class="card-body">
                    <h5 class="card-title" style="font-family: 'Playfair Display', serif;">
                        <?php echo $product['product_name']; ?>
                    </h5>
                    <p class="card-text text-muted">
                        <?php echo isset($product['description']) ? $product['description'] : 'No description'; ?>
                    </p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div>
                            <small class="text-muted">Price</small>
                            <h5 class="mb-0 text-primary">RM <?php echo number_format($product['price'], 2); ?></h5>
                        </div>
                        <div class="text-end">
                            <small class="text-muted">Stock</small>
                            <h5 class="mb-0 <?php echo $product['quantity'] <= 5 ? 'text-danger' : 'text-success'; ?>">
                                <?php echo $product['quantity']; ?>
                            </h5>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex gap-2">
                        <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" 
                           class="btn btn-success flex-grow-1">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="?delete=<?php echo $product['product_id']; ?>" 
                           class="btn btn-danger flex-grow-1"
                           onclick="return confirm('Delete this product?')">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>