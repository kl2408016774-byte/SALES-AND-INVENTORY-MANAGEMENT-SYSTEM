<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$where = "";
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$selected_month = isset($_GET['month']) ? $_GET['month'] : '';

if($selected_year) {
    $where .= " AND YEAR(sale_date)='$selected_year'";
}
if($selected_month) {
    $where .= " AND MONTH(sale_date)='$selected_month'";
}

// Get daily summary
$daily_query = mysqli_query($conn, "
    SELECT DATE(sale_date) as date, 
           COUNT(*) as transaction_count,
           SUM(quantity) as total_items,
           SUM(total_price) as total_sales
    FROM sales
    WHERE 1 $where
    GROUP BY DATE(sale_date)
    ORDER BY date DESC
");

// Get monthly totals
$monthly_total = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT SUM(total_price) as total,
           COUNT(DISTINCT DATE(sale_date)) as days_with_sales,
           COUNT(*) as total_transactions
    FROM sales
    WHERE 1 $where
"));

// Get years for dropdown
$years_query = mysqli_query($conn, "SELECT DISTINCT YEAR(sale_date) as year FROM sales ORDER BY year DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Monthly Summary - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <h2 class="mb-4" style="font-family: 'Playfair Display', serif;">📅 Monthly Sales Summary</h2>
    
    <!-- Filter Form -->
    <div class="card p-4 mb-4">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Year</label>
                <select name="year" class="form-select">
                    <?php 
                    while($year_row = mysqli_fetch_assoc($years_query)) { 
                        $selected = ($year_row['year'] == $selected_year) ? 'selected' : '';
                    ?>
                        <option value="<?php echo $year_row['year']; ?>" <?php echo $selected; ?>>
                            <?php echo $year_row['year']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            
            <div class="col-md-4">
                <label class="form-label">Month</label>
                <select name="month" class="form-select">
                    <option value="">All Months</option>
                    <?php for($m = 1; $m <= 12; $m++) { 
                        $month_name = date('F', mktime(0, 0, 0, $m, 1));
                        $selected = ($m == $selected_month) ? 'selected' : '';
                    ?>
                        <option value="<?php echo $m; ?>" <?php echo $selected; ?>><?php echo $month_name; ?></option>
                    <?php } ?>
                </select>
            </div>
            
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter me-2"></i>Apply Filter
                </button>
            </div>
        </form>
    </div>
    
    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-dollar-sign me-2"></i>Total Sales</h5>
                <div class="stat-number">RM <?php echo number_format($monthly_total['total'] ?? 0, 2); ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-shopping-bag me-2"></i>Transactions</h5>
                <div class="stat-number"><?php echo $monthly_total['total_transactions'] ?? 0; ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-calendar-check me-2"></i>Active Days</h5>
                <div class="stat-number"><?php echo $monthly_total['days_with_sales'] ?? 0; ?></div>
            </div>
        </div>
    </div>
    
    <!-- Daily Summary Table -->
    <div class="card p-4">
        <h5 class="mb-3" style="font-family: 'Playfair Display', serif;">Daily Breakdown</h5>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Transactions</th>
                        <th>Items Sold</th>
                        <th>Total Sales</th>
                        <th>Average per Transaction</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($daily_query) > 0) { ?>
                        <?php while($row = mysqli_fetch_assoc($daily_query)) { ?>
                        <tr>
                            <td><?php echo date('d M Y', strtotime($row['date'])); ?></td>
                            <td><?php echo $row['transaction_count']; ?></td>
                            <td><?php echo $row['total_items']; ?></td>
                            <td>RM <?php echo number_format($row['total_sales'], 2); ?></td>
                            <td>
                                RM <?php echo number_format($row['total_sales'] / $row['transaction_count'], 2); ?>
                            </td>
                        </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="5" class="text-center">No sales data found for the selected period</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>