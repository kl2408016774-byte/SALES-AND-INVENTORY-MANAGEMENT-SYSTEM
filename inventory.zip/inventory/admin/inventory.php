<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get all products with stock information
$products = mysqli_query($conn, "
    SELECT *, 
           CASE 
               WHEN quantity = 0 THEN 'Out of Stock'
               WHEN quantity <= 5 THEN 'Low Stock'
               ELSE 'In Stock'
           END as stock_status
    FROM products 
    ORDER BY 
        CASE 
            WHEN quantity = 0 THEN 1
            WHEN quantity <= 5 THEN 2
            ELSE 3
        END,
        product_name
");

// Get inventory statistics
$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM products"));
$total_value = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(price * quantity) as total FROM products"));
$low_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE quantity <= 5 AND quantity > 0"));
$out_of_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE quantity = 0"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <h2 class="mb-4" style="font-family: 'Playfair Display', serif;">📦 Inventory Management</h2>
    
    <!-- Inventory Statistics -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-boxes me-2"></i>Total Items</h5>
                <div class="stat-number"><?php echo $total_products['count']; ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-dollar-sign me-2"></i>Inventory Value</h5>
                <div class="stat-number">RM <?php echo number_format($total_value['total'] ?? 0, 2); ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-exclamation-triangle me-2" style="color: #ffb347;"></i>Low Stock</h5>
                <div class="stat-number" style="color: #ffb347;"><?php echo $low_stock['count']; ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-times-circle me-2" style="color: #ff6b81;"></i>Out of Stock</h5>
                <div class="stat-number" style="color: #ff6b81;"><?php echo $out_of_stock['count']; ?></div>
            </div>
        </div>
    </div>
    
    <!-- Inventory Table -->
    <div class="card p-4">
        <h5 class="mb-3" style="font-family: 'Playfair Display', serif;">Current Stock Levels</h5>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Current Stock</th>
                        <th>Status</th>
                        <th>Stock Value</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($product = mysqli_fetch_assoc($products)) { 
                        $status_class = '';
                        $status_icon = '';
                        
                        if($product['stock_status'] == 'Out of Stock') {
                            $status_class = 'badge-danger';
                            $status_icon = 'fa-times-circle';
                        } elseif($product['stock_status'] == 'Low Stock') {
                            $status_class = 'badge-warning';
                            $status_icon = 'fa-exclamation-triangle';
                        } else {
                            $status_class = 'badge-success';
                            $status_icon = 'fa-check-circle';
                        }
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo $product['product_name']; ?></strong><br>
                            <small class="text-muted"><?php echo $product['description']; ?></small>
                        </td>
                        <td>RM <?php echo number_format($product['price'], 2); ?></td>
                        <td>
                            <span class="fw-bold <?php echo $product['quantity'] <= 5 ? 'text-danger' : ''; ?>">
                                <?php echo $product['quantity']; ?> units
                            </span>
                        </td>
                        <td>
                            <span class="badge <?php echo $status_class; ?>">
                                <i class="fas <?php echo $status_icon; ?> me-1"></i>
                                <?php echo $product['stock_status']; ?>
                            </span>
                        </td>
                        <td>RM <?php echo number_format($product['price'] * $product['quantity'], 2); ?></td>
                        <td>
                            <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-success btn-sm">
                                <i class="fas fa-edit"></i> Update Stock
                            </a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>