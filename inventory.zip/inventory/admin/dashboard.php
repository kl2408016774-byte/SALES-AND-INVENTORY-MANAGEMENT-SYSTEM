<?php
include '../config.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: admin/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user info
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE user_id='$user_id'");
$user = mysqli_fetch_assoc($user_query);

// Get statistics
$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM products"));
$total_sales = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_price) as total FROM sales"));
$low_stock = mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE quantity <= 5");
$low_stock_count = mysqli_fetch_assoc($low_stock);

// Get recent sales
$recent_sales = mysqli_query($conn, "
    SELECT s.*, p.product_name 
    FROM sales s 
    JOIN products p ON s.product_id = p.product_id 
    ORDER BY s.sale_date DESC 
    LIMIT 5
");

// Get top products
$top_products = mysqli_query($conn, "
    SELECT p.product_name, SUM(s.quantity) as total_sold
    FROM sales s
    JOIN products p ON s.product_id = p.product_id
    GROUP BY p.product_id
    ORDER BY total_sold DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Makeup Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <!-- Welcome Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1" style="font-family: 'Playfair Display', serif;">Welcome back, <?php echo $user['name']; ?>! 💕</h2>
            <p class="text-muted">Here's what's happening with your makeup shop today</p>
        </div>
        <div class="text-end">
            <span class="badge" style="background: linear-gradient(135deg, #ff9a9e, #fad0c4); color: white; padding: 10px 20px;">
                <i class="fas fa-calendar me-2"></i><?php echo date('l, F j, Y'); ?>
            </span>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-box me-2"></i>Total Products</h5>
                <div class="stat-number"><?php echo $total_products['count']; ?></div>
                <p class="text-muted mb-0">+12% from last month</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-dollar-sign me-2"></i>Total Sales</h5>
                <div class="stat-number">RM <?php echo number_format($total_sales['total'] ?? 0, 2); ?></div>
                <p class="text-muted mb-0">+8% from last month</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-exclamation-triangle me-2"></i>Low Stock</h5>
                <div class="stat-number"><?php echo $low_stock_count['count']; ?></div>
                <p class="text-muted mb-0">Need to reorder</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5><i class="fas fa-star me-2"></i>Top Product</h5>
                <?php 
                $top = mysqli_fetch_assoc($top_products);
                ?>
                <div class="stat-number" style="font-size: 24px;"><?php echo $top['product_name'] ?? 'N/A'; ?></div>
                <p class="text-muted mb-0"><?php echo $top['total_sold'] ?? 0; ?> units sold</p>
            </div>
        </div>
    </div>

    <!-- Charts and Tables -->
    <div class="row g-4">
        <!-- Recent Sales -->
        <div class="col-md-7">
            <div class="widget">
                <div class="widget-title">
                    <i class="fas fa-clock"></i> Recent Sales
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($sale = mysqli_fetch_assoc($recent_sales)) { ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($sale['sale_date'])); ?></td>
                                <td><?php echo $sale['product_name']; ?></td>
                                <td><?php echo $sale['quantity']; ?></td>
                                <td>RM <?php echo number_format($sale['total_price'], 2); ?></td>
                                <td><span class="badge badge-success">Completed</span></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Top Products -->
        <div class="col-md-5">
            <div class="widget">
                <div class="widget-title">
                    <i class="fas fa-crown"></i> Top Selling Products
                </div>
                <div class="list-group list-group-flush">
                    <?php 
                    mysqli_data_seek($top_products, 0);
                    while($product = mysqli_fetch_assoc($top_products)) { 
                    ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 bg-transparent">
                        <div>
                            <h6 class="mb-0"><?php echo $product['product_name']; ?></h6>
                            <small class="text-muted">Units sold: <?php echo $product['total_sold']; ?></small>
                        </div>
                        <span class="badge" style="background: linear-gradient(135deg, #ff9a9e, #fad0c4); color: white; padding: 8px 15px;">
                            <?php echo $product['total_sold']; ?> sold
                        </span>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>