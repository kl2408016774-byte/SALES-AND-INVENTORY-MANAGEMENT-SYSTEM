<?php
include '../config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE user_id='$id'"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account - Makeup Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>💄 Makeup Shop</h3>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="products.php"><i class="fas fa-box"></i> Products</a>
    <a href="record_sale.php"><i class="fas fa-shopping-cart"></i> Sales</a>
    <a href="inventory.php"><i class="fas fa-warehouse"></i> Inventory</a>
    <a href="report.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="monthly_summary.php"><i class="fas fa-calendar-alt"></i> Monthly</a>
    <a href="account.php"><i class="fas fa-user"></i> Account</a>
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <h2 class="mb-4" style="font-family: 'Playfair Display', serif;">👤 My Account</h2>
    
    <div class="row">
        <div class="col-md-4">
            <div class="card text-center p-4">
                <div class="position-relative">
                    <?php if($user['profile_image'] && $user['profile_image'] != 'default.png') { ?>
                        <img src="../uploads/<?php echo $user['profile_image']; ?>" class="profile-image mb-3">
                    <?php } else { ?>
                        <div class="profile-image mb-3 d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, #ff9a9e, #fad0c4); color: white;">
                            <i class="fas fa-user fa-4x"></i>
                        </div>
                    <?php } ?>
                </div>
                
                <h4 style="font-family: 'Playfair Display', serif;"><?php echo $user['name']; ?></h4>
                <p class="text-muted"><i class="fas fa-envelope me-2"></i><?php echo $user['email']; ?></p>
                
                <hr>
                
                <div class="d-grid gap-2">
                    <a href="profile.php" class="btn btn-primary">
                        <i class="fas fa-user-edit me-2"></i>Edit Profile
                    </a>
                    <a href="change_password.php" class="btn btn-success">
                        <i class="fas fa-key me-2"></i>Change Password
                    </a>
                    <a href="../logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card p-4">
                <h5 class="mb-3" style="font-family: 'Playfair Display', serif;">📊 Account Statistics</h5>
                
                <?php
                // Get user statistics
                $total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM products"));
                $total_sales = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count, SUM(total_price) as total FROM sales"));
                $member_since = date('F j, Y', strtotime($user['created_at'] ?? 'now'));
                ?>
                
                <div class="row g-3">
                    <div class="col-6">
                        <div class="stat-card p-3">
                            <small class="text-muted">Member Since</small>
                            <h6 class="mb-0"><?php echo $member_since; ?></h6>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card p-3">
                            <small class="text-muted">Total Products</small>
                            <h6 class="mb-0"><?php echo $total_products['count']; ?></h6>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card p-3">
                            <small class="text-muted">Total Sales</small>
                            <h6 class="mb-0"><?php echo $total_sales['count']; ?></h6>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card p-3">
                            <small class="text-muted">Revenue</small>
                            <h6 class="mb-0">RM <?php echo number_format($total_sales['total'] ?? 0, 2); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>